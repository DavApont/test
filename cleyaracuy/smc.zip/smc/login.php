<h1>Acceso a CLEY en L&iacute;nea</h1>
<hr />
<form id="form-login" method="post" action="<?php echo $loginFormAction; ?>">
    <div class="adornoIzq"></div>
        <input type="text" name="usuario" id="usuario" onkeyup="this.value=this.value.toUpperCase()" />
    <div class="adornoDer"></div>
        <br clear="all" />
    <div class="adornoIzq"></div>
        <input type="password" name="contrasena" id="contrasena" />
    <div class="adornoDer"></div>
        <input type="submit" style="margin-top:7px;" name="entrar" id="entrar" value="Ingresar" />
</form> 
<a href="#smc/registro.php" style="display:block;float:left;margin-left:50px;margin-top:15px;">Reg&iacute;strate</a>
<a href="#smc/olvido_clave.php" style="display:block;float:right;margin-right:50px;margin-top:15px;">Olvid&eacute; mi Contrase&ntilde;a</a>