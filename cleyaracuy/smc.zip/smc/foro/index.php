<p>Administradores Globales</p>
<p>Moderadores</p>
<p><a href="index.php?id=2&vinculo=foro/crearforo.php">Foros</a></p>
<p><a href="index.php?id=2&vinculo=foro/config.php">Configaracion del Foro</a></p>
