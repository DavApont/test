<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>

<p><strong>Invita a los j&oacute;venes a unirse al partido</strong></p>
<p><strong>Shirley Romero ratific&oacute; su compromiso con el PSUV</strong></p>
<p>&nbsp;</p>
<p>La presidenta de la Comisi&oacute;n de Finanzas y Asuntos Laborales del Consejo Legislativo estadal Shirley Romero, renov&oacute; su compromiso con el Partido Socialista Unido de Venezuela (PSUV) tras acudir a la jornada nacional de inscripci&oacute;n y ratificaci&oacute;n de militancia.&nbsp;</p>
<p>&ldquo;Con esta acci&oacute;n estamos afianzando el Proyecto Sim&oacute;n Bol&iacute;var, &nbsp;&nbsp;nos merecemos un pa&iacute;s, estados y municipios digno donde la equidad y la igualdad sean las premisas para salir adelante y derrotar los vicios de las administraciones pasadas que tanto da&ntilde;o le hicieron al pueblo&rdquo;.</p>
<p>La legisladora coment&oacute; que el proceso es r&aacute;pido y muy sencillo, &ldquo;s&oacute;lo deben acercarse al punto rojo m&aacute;s cercano, all&iacute; un voluntario le pedir&aacute; su c&eacute;dula, si es nuevo militante llenar&aacute; un formato con sus datos, y si s&oacute;lo va a actualizar corroborar&aacute; junto con usted la informaci&oacute;n aparecida en la base de datos del partido&rdquo;.</p>
<p>Manifest&oacute; que la actividad ha sido un total &eacute;xito en la regi&oacute;n, &ldquo;Yaracuy ha dado una gran demostraci&oacute;n de apoyo, hemos superado todas las expectativas que ten&iacute;amos no s&oacute;lo para nuevos inscritos sino para actualizaciones, y a&uacute;n no hemos culminado el lapso&rdquo;.</p>
<p>Romero hizo un llamado a los j&oacute;venes para que se sumen a las filas de la revoluci&oacute;n, y sean los grandes protagonistas de una nueva patria rumbo al socialismo del siglo XXI.</p>
<p>&ldquo;Por primera vez en la historia pol&iacute;tica del pa&iacute;s todo aquel que tenga 16 a&ntilde;os puede inscribirse y formar desde ya parte de este gran proyecto que lidera nuestro Presidente Hugo Rafael Ch&aacute;vez Fr&iacute;as, estos 10 a&ntilde;os no tienen comparaci&oacute;n con el pasado, los niveles de participaci&oacute;n as&iacute; lo han indicado&rdquo;.</p>
<p>CRONOGRAMA DE UBICACI&Oacute;N DE LAS MAQUINAS PARA LA INSCRIPCION Y ACTUALIZACION DE DATOS DE MILITANTES DEL PSUV EN EL MUNICIPIO PE&Ntilde;A</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="150" valign="top">
<p>Nro</p>
</td>
<td width="150" valign="top">
<p>VIERNES   29/05/09</p>
</td>
<td width="150" valign="top">
<p>SABADO   30/05/09</p>
</td>
<td width="150" valign="top">
<p>DOMINGO   31/05/09</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1</p>
</td>
<td width="150" valign="top">
<p>EL   Peg&oacute;n (Ma&ntilde;ana)</p>
<p>Ovidio   March&aacute;n (Tarde)</p>
</td>
<td width="150" valign="top">
<p>La   Piedra (Pueblo Nuevo)</p>
</td>
<td width="150" valign="top">
<p>Ca&ntilde;averal</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2</p>
</td>
<td width="150" valign="top">
<p>Plaza</p>
</td>
<td width="150" valign="top">
<p>Plaza</p>
</td>
<td width="150" valign="top">
<p>Plaza</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3</p>
</td>
<td width="150" valign="top">
<p>Sabanita</p>
</td>
<td width="150" valign="top">
<p>Sabanita   (Jos&eacute; Alvarado)</p>
</td>
<td width="150" valign="top">
<p>Mercado   Municipal</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4</p>
</td>
<td width="150" valign="top">
<p>Trocadero</p>
</td>
<td width="150" valign="top">
<p>Cujisal   (Ma&ntilde;ana)</p>
<p>La   Ensenada (Tarde)</p>
</td>
<td width="150" valign="top">
<p>Trocadero</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5</p>
</td>
<td width="150" valign="top">
<p>Daniel   Car&iacute;as (Fruter&iacute;a)</p>
</td>
<td width="150" valign="top">
<p>San   Jos&eacute; (Stadium)</p>
</td>
<td width="150" valign="top">
<p>Limoncito</p>
</td>
</tr>
<tr>
<td width="150" valign="top">
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6</p>
</td>
<td width="150" valign="top">
<p>Tricentenaria</p>
</td>
<td width="150" valign="top">
<p>Aminta   Abreu</p>
<p>La   Popular&nbsp; (3pm a 6pm)</p>
</td>
<td width="150" valign="top">
<p>La   Mora (9am a 11am)</p>
<p>Don   Nicola (12m a 6pm)</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>FOTOLEYENDA: &nbsp;(cu) La legisladora Shirley Romero invita a todos los yaracuyanos a unirse a las filas del PSUV</p>

</body>
</html>