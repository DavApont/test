<?php

?>

<h1>Informa sobre los casos en tu Comisi&oacute;n</h1>
<p>A trav&eacute;s de este m&oacute;dulo podr&aacute;s informar sobre el status y progreso de los casos que hayan sido remitidos a tu Comisi&oacute;n Permanente desde la plenaria de este parlamento regional. Cabe destacar que solamente podr&aacute;s trabajar en los casos que previamente hayan sido cargados al Sistema y que se te hayan asignado o remitido.</p>
<hr />